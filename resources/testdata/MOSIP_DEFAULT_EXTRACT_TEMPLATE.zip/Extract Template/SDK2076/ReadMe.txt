Contains the biometric extract template probe data for SDK test case with face exception scenario.


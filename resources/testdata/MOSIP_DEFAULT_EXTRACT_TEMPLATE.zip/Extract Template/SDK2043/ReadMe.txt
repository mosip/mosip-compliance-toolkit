extractTemplateAndCheckQualityFail

probe iris good quality
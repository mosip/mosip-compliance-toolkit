extractTemplateAndCheckQualitySuccess

probe face good quality
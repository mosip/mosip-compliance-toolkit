extractTemplateAndCheckQualitySuccess

probe iris good quality
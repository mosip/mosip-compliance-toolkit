extractTemplateAndCheckQualityFail

probe finger good quality
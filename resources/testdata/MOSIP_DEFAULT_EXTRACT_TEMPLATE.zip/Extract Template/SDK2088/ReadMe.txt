Contains the biometric extract template probe data for SDK test case with finger exception scenario.


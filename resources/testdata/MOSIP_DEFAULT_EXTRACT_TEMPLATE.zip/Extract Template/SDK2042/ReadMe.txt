extractTemplateAndCheckQualityFail

probe face good quality
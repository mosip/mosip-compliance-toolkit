extractTemplateAndCheckQualitySuccess

probe finger good quality
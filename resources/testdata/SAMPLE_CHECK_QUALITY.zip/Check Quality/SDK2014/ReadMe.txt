modality quality check success
-face
-finger
-iris
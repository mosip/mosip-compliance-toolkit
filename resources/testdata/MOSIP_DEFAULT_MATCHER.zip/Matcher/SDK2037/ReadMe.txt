modality match success - multi gallery
-face
-finger
-iris